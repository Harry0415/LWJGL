/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.bgfx;

import javax.annotation.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.Checks.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * Transient vertex buffer.
 * 
 * <h3>Member documentation</h3>
 * 
 * <ul>
 * <li>{@code data} &ndash; pointer to data</li>
 * <li>{@code size} &ndash; data size</li>
 * <li>{@code startVertex} &ndash; first vertex</li>
 * <li>{@code stride} &ndash; vertex stride</li>
 * <li>{@code handle} &ndash; vertex buffer handle</li>
 * <li>{@code layoutHandle} &ndash; vertex layout handle</li>
 * </ul>
 * 
 * <h3>Layout</h3>
 * 
 * <pre><code>
 * struct bgfx_transient_vertex_buffer_t {
 *     uint8_t * data;
 *     uint32_t size;
 *     uint32_t startVertex;
 *     uint16_t stride;
 *     bgfx_vertex_buffer_handle_t handle;
 *     bgfx_vertex_layout_handle_t layoutHandle;
 * }</code></pre>
 */
@NativeType("struct bgfx_transient_vertex_buffer_t")
public class BGFXTransientVertexBuffer extends Struct implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        DATA,
        SIZE,
        STARTVERTEX,
        STRIDE,
        HANDLE,
        LAYOUTHANDLE;

    static {
        Layout layout = __struct(
            __member(POINTER_SIZE),
            __member(4),
            __member(4),
            __member(2),
            __member(2),
            __member(2)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        DATA = layout.offsetof(0);
        SIZE = layout.offsetof(1);
        STARTVERTEX = layout.offsetof(2);
        STRIDE = layout.offsetof(3);
        HANDLE = layout.offsetof(4);
        LAYOUTHANDLE = layout.offsetof(5);
    }

    /**
     * Creates a {@code BGFXTransientVertexBuffer} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public BGFXTransientVertexBuffer(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** Returns a {@link ByteBuffer} view of the data pointed to by the {@code data} field. */
    @NativeType("uint8_t *")
    public ByteBuffer data() { return ndata(address()); }
    /** Returns the value of the {@code size} field. */
    @NativeType("uint32_t")
    public int size() { return nsize(address()); }
    /** Returns the value of the {@code startVertex} field. */
    @NativeType("uint32_t")
    public int startVertex() { return nstartVertex(address()); }
    /** Returns the value of the {@code stride} field. */
    @NativeType("uint16_t")
    public short stride() { return nstride(address()); }
    /** Returns the value of the {@code handle} field. */
    @NativeType("bgfx_vertex_buffer_handle_t")
    public short handle() { return nhandle(address()); }
    /** Returns the value of the {@code layoutHandle} field. */
    @NativeType("bgfx_vertex_layout_handle_t")
    public short layoutHandle() { return nlayoutHandle(address()); }

    /** Sets the address of the specified {@link ByteBuffer} to the {@code data} field. */
    public BGFXTransientVertexBuffer data(@NativeType("uint8_t *") ByteBuffer value) { ndata(address(), value); return this; }
    /** Sets the specified value to the {@code startVertex} field. */
    public BGFXTransientVertexBuffer startVertex(@NativeType("uint32_t") int value) { nstartVertex(address(), value); return this; }
    /** Sets the specified value to the {@code stride} field. */
    public BGFXTransientVertexBuffer stride(@NativeType("uint16_t") short value) { nstride(address(), value); return this; }
    /** Sets the specified value to the {@code handle} field. */
    public BGFXTransientVertexBuffer handle(@NativeType("bgfx_vertex_buffer_handle_t") short value) { nhandle(address(), value); return this; }
    /** Sets the specified value to the {@code layoutHandle} field. */
    public BGFXTransientVertexBuffer layoutHandle(@NativeType("bgfx_vertex_layout_handle_t") short value) { nlayoutHandle(address(), value); return this; }

    /** Initializes this struct with the specified values. */
    public BGFXTransientVertexBuffer set(
        ByteBuffer data,
        int startVertex,
        short stride,
        short handle,
        short layoutHandle
    ) {
        data(data);
        startVertex(startVertex);
        stride(stride);
        handle(handle);
        layoutHandle(layoutHandle);

        return this;
    }

    /**
     * Copies the specified struct data to this struct.
     *
     * @param src the source struct
     *
     * @return this struct
     */
    public BGFXTransientVertexBuffer set(BGFXTransientVertexBuffer src) {
        memCopy(src.address(), address(), SIZEOF);
        return this;
    }

    // -----------------------------------

    /** Returns a new {@code BGFXTransientVertexBuffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static BGFXTransientVertexBuffer malloc() {
        return wrap(BGFXTransientVertexBuffer.class, nmemAllocChecked(SIZEOF));
    }

    /** Returns a new {@code BGFXTransientVertexBuffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static BGFXTransientVertexBuffer calloc() {
        return wrap(BGFXTransientVertexBuffer.class, nmemCallocChecked(1, SIZEOF));
    }

    /** Returns a new {@code BGFXTransientVertexBuffer} instance allocated with {@link BufferUtils}. */
    public static BGFXTransientVertexBuffer create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return wrap(BGFXTransientVertexBuffer.class, memAddress(container), container);
    }

    /** Returns a new {@code BGFXTransientVertexBuffer} instance for the specified memory address. */
    public static BGFXTransientVertexBuffer create(long address) {
        return wrap(BGFXTransientVertexBuffer.class, address);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    @Nullable
    public static BGFXTransientVertexBuffer createSafe(long address) {
        return address == NULL ? null : wrap(BGFXTransientVertexBuffer.class, address);
    }

    /**
     * Returns a new {@link BGFXTransientVertexBuffer.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer malloc(int capacity) {
        return wrap(Buffer.class, nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link BGFXTransientVertexBuffer.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer calloc(int capacity) {
        return wrap(Buffer.class, nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link BGFXTransientVertexBuffer.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return wrap(Buffer.class, memAddress(container), capacity, container);
    }

    /**
     * Create a {@link BGFXTransientVertexBuffer.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer create(long address, int capacity) {
        return wrap(Buffer.class, address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    @Nullable
    public static BGFXTransientVertexBuffer.Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : wrap(Buffer.class, address, capacity);
    }

    // -----------------------------------

    /** Returns a new {@code BGFXTransientVertexBuffer} instance allocated on the thread-local {@link MemoryStack}. */
    public static BGFXTransientVertexBuffer mallocStack() {
        return mallocStack(stackGet());
    }

    /** Returns a new {@code BGFXTransientVertexBuffer} instance allocated on the thread-local {@link MemoryStack} and initializes all its bits to zero. */
    public static BGFXTransientVertexBuffer callocStack() {
        return callocStack(stackGet());
    }

    /**
     * Returns a new {@code BGFXTransientVertexBuffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static BGFXTransientVertexBuffer mallocStack(MemoryStack stack) {
        return wrap(BGFXTransientVertexBuffer.class, stack.nmalloc(ALIGNOF, SIZEOF));
    }

    /**
     * Returns a new {@code BGFXTransientVertexBuffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static BGFXTransientVertexBuffer callocStack(MemoryStack stack) {
        return wrap(BGFXTransientVertexBuffer.class, stack.ncalloc(ALIGNOF, 1, SIZEOF));
    }

    /**
     * Returns a new {@link BGFXTransientVertexBuffer.Buffer} instance allocated on the thread-local {@link MemoryStack}.
     *
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer mallocStack(int capacity) {
        return mallocStack(capacity, stackGet());
    }

    /**
     * Returns a new {@link BGFXTransientVertexBuffer.Buffer} instance allocated on the thread-local {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer callocStack(int capacity) {
        return callocStack(capacity, stackGet());
    }

    /**
     * Returns a new {@link BGFXTransientVertexBuffer.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer mallocStack(int capacity, MemoryStack stack) {
        return wrap(Buffer.class, stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link BGFXTransientVertexBuffer.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static BGFXTransientVertexBuffer.Buffer callocStack(int capacity, MemoryStack stack) {
        return wrap(Buffer.class, stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #data() data}. */
    public static ByteBuffer ndata(long struct) { return memByteBuffer(memGetAddress(struct + BGFXTransientVertexBuffer.DATA), nsize(struct)); }
    /** Unsafe version of {@link #size}. */
    public static int nsize(long struct) { return UNSAFE.getInt(null, struct + BGFXTransientVertexBuffer.SIZE); }
    /** Unsafe version of {@link #startVertex}. */
    public static int nstartVertex(long struct) { return UNSAFE.getInt(null, struct + BGFXTransientVertexBuffer.STARTVERTEX); }
    /** Unsafe version of {@link #stride}. */
    public static short nstride(long struct) { return UNSAFE.getShort(null, struct + BGFXTransientVertexBuffer.STRIDE); }
    /** Unsafe version of {@link #handle}. */
    public static short nhandle(long struct) { return UNSAFE.getShort(null, struct + BGFXTransientVertexBuffer.HANDLE); }
    /** Unsafe version of {@link #layoutHandle}. */
    public static short nlayoutHandle(long struct) { return UNSAFE.getShort(null, struct + BGFXTransientVertexBuffer.LAYOUTHANDLE); }

    /** Unsafe version of {@link #data(ByteBuffer) data}. */
    public static void ndata(long struct, ByteBuffer value) { memPutAddress(struct + BGFXTransientVertexBuffer.DATA, memAddress(value)); nsize(struct, value.remaining()); }
    /** Sets the specified value to the {@code size} field of the specified {@code struct}. */
    public static void nsize(long struct, int value) { UNSAFE.putInt(null, struct + BGFXTransientVertexBuffer.SIZE, value); }
    /** Unsafe version of {@link #startVertex(int) startVertex}. */
    public static void nstartVertex(long struct, int value) { UNSAFE.putInt(null, struct + BGFXTransientVertexBuffer.STARTVERTEX, value); }
    /** Unsafe version of {@link #stride(short) stride}. */
    public static void nstride(long struct, short value) { UNSAFE.putShort(null, struct + BGFXTransientVertexBuffer.STRIDE, value); }
    /** Unsafe version of {@link #handle(short) handle}. */
    public static void nhandle(long struct, short value) { UNSAFE.putShort(null, struct + BGFXTransientVertexBuffer.HANDLE, value); }
    /** Unsafe version of {@link #layoutHandle(short) layoutHandle}. */
    public static void nlayoutHandle(long struct, short value) { UNSAFE.putShort(null, struct + BGFXTransientVertexBuffer.LAYOUTHANDLE, value); }

    /**
     * Validates pointer members that should not be {@code NULL}.
     *
     * @param struct the struct to validate
     */
    public static void validate(long struct) {
        check(memGetAddress(struct + BGFXTransientVertexBuffer.DATA));
    }

    /**
     * Calls {@link #validate(long)} for each struct contained in the specified struct array.
     *
     * @param array the struct array to validate
     * @param count the number of structs in {@code array}
     */
    public static void validate(long array, int count) {
        for (int i = 0; i < count; i++) {
            validate(array + Integer.toUnsignedLong(i) * SIZEOF);
        }
    }

    // -----------------------------------

    /** An array of {@link BGFXTransientVertexBuffer} structs. */
    public static class Buffer extends StructBuffer<BGFXTransientVertexBuffer, Buffer> implements NativeResource {

        private static final BGFXTransientVertexBuffer ELEMENT_FACTORY = BGFXTransientVertexBuffer.create(-1L);

        /**
         * Creates a new {@code BGFXTransientVertexBuffer.Buffer} instance backed by the specified container.
         *
         * Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link BGFXTransientVertexBuffer#SIZEOF}, and its mark will be undefined.
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected BGFXTransientVertexBuffer getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** Returns a {@link ByteBuffer} view of the data pointed to by the {@code data} field. */
        @NativeType("uint8_t *")
        public ByteBuffer data() { return BGFXTransientVertexBuffer.ndata(address()); }
        /** Returns the value of the {@code size} field. */
        @NativeType("uint32_t")
        public int size() { return BGFXTransientVertexBuffer.nsize(address()); }
        /** Returns the value of the {@code startVertex} field. */
        @NativeType("uint32_t")
        public int startVertex() { return BGFXTransientVertexBuffer.nstartVertex(address()); }
        /** Returns the value of the {@code stride} field. */
        @NativeType("uint16_t")
        public short stride() { return BGFXTransientVertexBuffer.nstride(address()); }
        /** Returns the value of the {@code handle} field. */
        @NativeType("bgfx_vertex_buffer_handle_t")
        public short handle() { return BGFXTransientVertexBuffer.nhandle(address()); }
        /** Returns the value of the {@code layoutHandle} field. */
        @NativeType("bgfx_vertex_layout_handle_t")
        public short layoutHandle() { return BGFXTransientVertexBuffer.nlayoutHandle(address()); }

        /** Sets the address of the specified {@link ByteBuffer} to the {@code data} field. */
        public BGFXTransientVertexBuffer.Buffer data(@NativeType("uint8_t *") ByteBuffer value) { BGFXTransientVertexBuffer.ndata(address(), value); return this; }
        /** Sets the specified value to the {@code startVertex} field. */
        public BGFXTransientVertexBuffer.Buffer startVertex(@NativeType("uint32_t") int value) { BGFXTransientVertexBuffer.nstartVertex(address(), value); return this; }
        /** Sets the specified value to the {@code stride} field. */
        public BGFXTransientVertexBuffer.Buffer stride(@NativeType("uint16_t") short value) { BGFXTransientVertexBuffer.nstride(address(), value); return this; }
        /** Sets the specified value to the {@code handle} field. */
        public BGFXTransientVertexBuffer.Buffer handle(@NativeType("bgfx_vertex_buffer_handle_t") short value) { BGFXTransientVertexBuffer.nhandle(address(), value); return this; }
        /** Sets the specified value to the {@code layoutHandle} field. */
        public BGFXTransientVertexBuffer.Buffer layoutHandle(@NativeType("bgfx_vertex_layout_handle_t") short value) { BGFXTransientVertexBuffer.nlayoutHandle(address(), value); return this; }

    }

}