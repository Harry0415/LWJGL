/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.bullet {
    requires transitive org.lwjgl;

    exports org.lwjgl.bullet;
}