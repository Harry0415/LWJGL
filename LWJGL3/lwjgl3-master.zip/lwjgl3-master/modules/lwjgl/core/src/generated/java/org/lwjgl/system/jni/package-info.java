/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */

/** Contains bindings to the Java Native Interface (JNI). */
@org.lwjgl.system.NonnullDefault
package org.lwjgl.system.jni;

