/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */

/** Contains bindings to native APIs specific to the Linux operating system. */
@org.lwjgl.system.NonnullDefault
package org.lwjgl.system.linux;

