# LWJGL Project Modules

### extract

A tool that extracts generator templates from native headers. (experimental)

### generator

The source code Generator and related tools. Used only for building
LWJGL, there is no runtime dependency to it.

### lwjgl

The LWJGL core and bindings. Includes the generator templates and
generated code.

### samples

The LWJGL demo & benchmarking suite.