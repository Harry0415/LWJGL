## Contributors

Thank you to all the people who have contributed to LWJGL! [[Contribute](https://github.com/LWJGL/lwjgl3/blob/master/.github/CONTRIBUTING.md)]
<a href="https://github.com/LWJGL/lwjgl3/graphs/contributors"><img src="https://opencollective.com/lwjgl/contributors.svg?width=825"/></a>

## Backers

Thank you to all our backers! [[Become a backer](https://opencollective.com/lwjgl#contribute)]

### People

![Backers](https://opencollective.com/lwjgl/backers.svg?width=825)

### Organizations

![Sponsors](https://opencollective.com/lwjgl/sponsors.svg?width=825)

## Sponsors

Special thank you to our sponsors! [[Become a sponsor](https://opencollective.com/lwjgl#contribute)]

### Bronze 🥉

<a href="https://opencollective.com/lwjgl/tiers/bronze-sponsor/0/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/bronze-sponsor/0/avatar.svg"></a>

### Silver 🥈

<a href="https://opencollective.com/lwjgl/tiers/silver-sponsor/0/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/silver-sponsor/0/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/silver-sponsor/1/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/silver-sponsor/1/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/silver-sponsor/2/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/silver-sponsor/2/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/silver-sponsor/3/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/silver-sponsor/3/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/silver-sponsor/4/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/silver-sponsor/4/avatar.svg"></a>

### Gold 🥇

<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/0/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/0/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/1/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/1/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/2/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/2/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/3/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/3/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/4/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/4/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/5/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/5/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/6/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/6/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/7/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/7/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/8/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/8/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/9/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/9/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/10/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/10/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/11/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/11/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/12/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/12/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/13/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/13/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/14/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/14/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/15/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/15/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/16/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/16/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/17/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/17/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/18/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/18/avatar.svg"></a>
<a href="https://opencollective.com/lwjgl/tiers/gold-sponsor/19/website" target="_blank"><img src="https://opencollective.com/lwjgl/tiers/gold-sponsor/19/avatar.svg"></a>
